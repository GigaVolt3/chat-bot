require('dotenv').config();
const express = require('express');
const { SessionsClient, IntentsClient } = require('@google-cloud/dialogflow');
const cors = require('cors');
const http = require('http');
const socketIo = require('socket.io');
const fetch = require('node-fetch');
const { google } = require('googleapis');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

app.use(cors());
app.use(express.static('public'));
app.use(express.json());

// Dialogflow client configuration
const dialogflowConfig = {
  projectId: process.env.DIALOGFLOW_PROJECT_ID,
  credentials: {
    client_email: process.env.DIALOGFLOW_CLIENT_EMAIL,
    private_key: process.env.DIALOGFLOW_PRIVATE_KEY.replace(/\\n/g, '\n')
  }
};

const sessionClient = new SessionsClient(dialogflowConfig);
const intentsClient = new IntentsClient(dialogflowConfig);
const projectId = process.env.DIALOGFLOW_PROJECT_ID;

// Store active sessions and created intents
const sessions = new Map();
const createdIntents = new Set();

// Get Google OAuth2 access token
async function getAccessToken() {
  try {
    const auth = new google.auth.GoogleAuth({
      credentials: dialogflowConfig.credentials,
      scopes: ['https://www.googleapis.com/auth/cloud-platform']
    });
    
    const client = await auth.getClient();
    const tokenResponse = await client.getAccessToken();
    return tokenResponse.token;
  } catch (error) {
    console.error('Error getting access token:', error);
    throw error;
  }
}

// Call Groq API for intent suggestions
async function callGroqForIntentSuggestion(userText) {
  console.log('Calling Groq API for intent suggestion with message:', userText);
  try {
    const apiKey = process.env.GROQ_API_KEY;
    const systemPrompt = `You are helping build Dialogflow intents automatically.

Given a user message, you must:
1) Decide if this is a reusable pattern that deserves an intent.
2) If yes, propose:
   - a clean intent_name (use underscores, no spaces, be descriptive)
   - 3-5 training phrases (similar variations to the user text)
   - a short response_template the bot should say
3) If the message is too random, very personal, contains personal info (phone, email), or one-time use, set should_create_intent = false.

Respond ONLY with valid JSON with these exact keys:
{
  "answer_text": "string - what the bot should reply now",
  "should_create_intent": boolean,
  "intent_name": "string or null",
  "training_phrases": ["array of strings or empty"],
  "response_template": "string or null"
}`;

    const requestBody = {
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userText }
      ],
      model: 'llama-3.1-8b-instant',
      temperature: 0.5,
      max_tokens: 500
    };

    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify(requestBody)
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Groq API error (${response.status}): ${errorText}`);
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;
    
    // Parse the JSON response
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error('No JSON found in Groq response');
    }
    
    const parsed = JSON.parse(jsonMatch[0]);
    console.log('Groq intent suggestion:', parsed);
    
    return {
      answer_text: parsed.answer_text || 'I can help you with that.',
      should_create_intent: parsed.should_create_intent || false,
      intent_name: parsed.intent_name || null,
      training_phrases: parsed.training_phrases || [],
      response_template: parsed.response_template || null
    };
  } catch (error) {
    console.error('Error calling Groq for intent suggestion:', error);
    return {
      answer_text: 'I can help you with that.',
      should_create_intent: false,
      intent_name: null,
      training_phrases: [],
      response_template: null
    };
  }
}

// Find similar intent by name or training phrases
async function findSimilarIntent(intentName, trainingPhrases) {
  try {
    const projectAgentPath = intentsClient.projectAgentPath(projectId);
    const [intents] = await intentsClient.listIntents({ 
      parent: projectAgentPath,
      intentView: 'INTENT_VIEW_FULL'
    });
    
    // First, check for exact name match
    const exactMatch = intents.find(intent => 
      intent.displayName.toLowerCase() === intentName.toLowerCase()
    );
    
    if (exactMatch) {
      return exactMatch;
    }
    
    // Check for similar names (partial match)
    const similarByName = intents.find(intent => {
      const name1 = intent.displayName.toLowerCase().replace(/[_\s-]/g, '');
      const name2 = intentName.toLowerCase().replace(/[_\s-]/g, '');
      return name1.includes(name2) || name2.includes(name1);
    });
    
    if (similarByName) {
      return similarByName;
    }
    
    // Check for similar training phrases
    if (trainingPhrases && trainingPhrases.length > 0) {
      for (const intent of intents) {
        if (intent.trainingPhrases && intent.trainingPhrases.length > 0) {
          const existingPhrases = intent.trainingPhrases.map(tp => 
            tp.parts.map(p => p.text).join('').toLowerCase()
          );
          
          for (const newPhrase of trainingPhrases) {
            const newPhraseLower = newPhrase.toLowerCase();
            for (const existingPhrase of existingPhrases) {
              // Calculate similarity (simple word overlap)
              const words1 = new Set(existingPhrase.split(/\s+/));
              const words2 = new Set(newPhraseLower.split(/\s+/));
              const intersection = new Set([...words1].filter(x => words2.has(x)));
              const similarity = intersection.size / Math.min(words1.size, words2.size);
              
              if (similarity > 0.6) {
                return intent;
              }
            }
          }
        }
      }
    }
    
    return null;
  } catch (error) {
    console.error('Error finding similar intent:', error);
    return null;
  }
}

// Update existing intent with new training phrases
async function updateDialogflowIntent(existingIntent, newTrainingPhrases, newResponseText) {
  try {
    // Get existing training phrases - KEEP ALL OF THEM
    const existingPhrases = existingIntent.trainingPhrases || [];
    const existingTexts = new Set(
      existingPhrases.map(tp => tp.parts.map(p => p.text).join('').toLowerCase())
    );
    
    // Filter out only exact duplicates (keep all unique new phrases)
    const uniqueNewPhrases = newTrainingPhrases.filter(phrase => 
      !existingTexts.has(phrase.toLowerCase())
    );
    
    if (uniqueNewPhrases.length === 0) {
      console.log(`No new unique phrases to add to intent: ${existingIntent.displayName}`);
      console.log(`  Existing phrases preserved: ${existingPhrases.length}`);
      return false;
    }
    
    // Format new training phrases
    const formattedNewPhrases = uniqueNewPhrases.map(phrase => ({
      type: 'EXAMPLE',
      parts: [{ text: phrase }]
    }));
    
    // Combine existing and new phrases - KEEPING ALL EXISTING ONES
    const updatedTrainingPhrases = [...existingPhrases, ...formattedNewPhrases];
    
    // Get existing responses - KEEP ALL OF THEM
    const existingMessages = existingIntent.messages || [];
    const existingResponseTexts = existingMessages
      .filter(msg => msg.text && msg.text.text)
      .flatMap(msg => msg.text.text);
    
    // Add new response ONLY if it's not already there
    let updatedMessages = [...existingMessages];
    if (newResponseText && !existingResponseTexts.includes(newResponseText)) {
      // Add as a new text response variant
      const textMessages = updatedMessages.filter(msg => msg.text);
      if (textMessages.length > 0) {
        // Add to existing text response
        if (!textMessages[0].text.text.includes(newResponseText)) {
          textMessages[0].text.text.push(newResponseText);
        }
      } else {
        // Create new text response
        updatedMessages.push({
          text: {
            text: [newResponseText]
          }
        });
      }
    }
    
    // Update the intent with ALL existing data preserved
    const updatedIntent = {
      name: existingIntent.name,
      displayName: existingIntent.displayName,
      trainingPhrases: updatedTrainingPhrases,
      messages: updatedMessages,
      priority: existingIntent.priority,
      isFallback: existingIntent.isFallback,
      webhookState: existingIntent.webhookState,
      inputContextNames: existingIntent.inputContextNames,
      outputContexts: existingIntent.outputContexts,
      parameters: existingIntent.parameters
    };
    
    console.log(`Updating intent: ${existingIntent.displayName}`);
    console.log(`  Existing training phrases: ${existingPhrases.length}`);
    console.log(`  New training phrases added: ${uniqueNewPhrases.length}`);
    console.log(`  Total training phrases: ${updatedTrainingPhrases.length}`);
    console.log(`  Total responses: ${updatedMessages.filter(m => m.text).map(m => m.text.text.length).reduce((a, b) => a + b, 0)}`);
    
    await intentsClient.updateIntent({
      intent: updatedIntent,
      languageCode: 'en'
    });
    
    console.log(`✓ Successfully updated intent: ${existingIntent.displayName}`);
    return true;
  } catch (error) {
    console.error('Error updating Dialogflow intent:', error);
    return false;
  }
}

// Create new intent in Dialogflow
async function createDialogflowIntent(displayName, trainingPhrases, responseText) {
  // Safety checks
  if (!displayName || displayName.trim() === '') {
    console.log('Intent creation skipped: empty display name');
    return false;
  }
  
  if (!trainingPhrases || trainingPhrases.length === 0) {
    console.log('Intent creation skipped: no training phrases');
    return false;
  }
  
  if (!responseText || responseText.trim() === '') {
    console.log('Intent creation skipped: empty response');
    return false;
  }
  
  try {
    const projectAgentPath = intentsClient.projectAgentPath(projectId);
    
    // Format training phrases for Dialogflow
    const formattedTrainingPhrases = trainingPhrases.map(phrase => ({
      type: 'EXAMPLE',
      parts: [{ text: phrase }]
    }));
    
    // Create the intent
    const intent = {
      displayName: displayName,
      trainingPhrases: formattedTrainingPhrases,
      messages: [{
        text: {
          text: [responseText]
        }
      }]
    };
    
    console.log('Creating new intent:', displayName);
    const [response] = await intentsClient.createIntent({
      parent: projectAgentPath,
      intent: intent
    });
    
    console.log(`✓ Successfully created intent: ${displayName}`);
    createdIntents.add(displayName);
    return true;
  } catch (error) {
    console.error('Error creating Dialogflow intent:', error);
    return false;
  }
}

// Main function to create or update intent
async function createOrUpdateIntent(displayName, trainingPhrases, responseText) {
  // Safety checks
  if (!displayName || !trainingPhrases || trainingPhrases.length === 0 || !responseText) {
    console.log('Intent creation/update skipped: missing required data');
    return false;
  }
  
  // Check if similar intent exists
  const similarIntent = await findSimilarIntent(displayName, trainingPhrases);
  
  if (similarIntent) {
    console.log(`Found similar intent: ${similarIntent.displayName}`);
    return await updateDialogflowIntent(similarIntent, trainingPhrases, responseText);
  } else {
    console.log(`No similar intent found, creating new intent: ${displayName}`);
    return await createDialogflowIntent(displayName, trainingPhrases, responseText);
  }
}

// Check Dialogflow connection
async function checkDialogflowConnection() {
  try {
    const sessionId = 'test-session-' + Math.random().toString(36).substring(7);
    const sessionPath = sessionClient.projectAgentSessionPath(projectId, sessionId);
    
    await sessionClient.detectIntent({
      session: sessionPath,
      queryInput: {
        text: {
          text: 'test',
          languageCode: 'en-US',
        },
      },
    });
    
    return { 
      status: 'connected', 
      message: 'Successfully connected to Dialogflow.'
    };
  } catch (error) {
    console.error('Dialogflow connection error:', error);
    return { 
      status: 'error', 
      message: 'Failed to connect to Dialogflow', 
      error: error.message 
    };
  }
}

// Handle chat messages with auto-intent creation/update
async function detectIntent(sessionId, message) {
  const sessionPath = sessionClient.projectAgentSessionPath(projectId, sessionId);
  
  const request = {
    session: sessionPath,
    queryInput: {
      text: {
        text: message,
        languageCode: 'en-US',
      },
    },
  };

  try {
    const responses = await sessionClient.detectIntent(request);
    const result = responses[0].queryResult;
    
    // Check if this is a fallback intent or low confidence
    const isFallback = result.intent.displayName === 'Default Fallback Intent' || 
                      result.intentDetectionConfidence < 0.5;
    
    let responseText = result.fulfillmentText;
    
    // If it's a fallback, use Groq with intent creation/update logic
    if (isFallback) {
      console.log('Fallback detected, calling Groq for intent suggestion...');
      const groqResult = await callGroqForIntentSuggestion(message);
      responseText = groqResult.answer_text;
      
      // If Groq suggests creating an intent, create or update it
      if (groqResult.should_create_intent && groqResult.intent_name) {
        console.log(`Groq suggests creating/updating intent: ${groqResult.intent_name}`);
        const success = await createOrUpdateIntent(
          groqResult.intent_name,
          groqResult.training_phrases,
          groqResult.response_template
        );
        
        if (success) {
          console.log('✓ Intent processed successfully');
        }
      }
    }
    
    return {
      text: responseText,
      intent: result.intent.displayName,
      confidence: result.intentDetectionConfidence
    };
  } catch (error) {
    console.error('Error detecting intent:', error);
    // Fall back to Groq
    const groqResult = await callGroqForIntentSuggestion(message);
    return { 
      text: groqResult.answer_text,
      intent: 'groq-fallback',
      confidence: 0.5
    };
  }
}

// Socket.io connection
io.on('connection', (socket) => {
  console.log('New client connected');
  const sessionId = socket.id;
  
  sessions.set(sessionId, { id: sessionId });
  
  checkDialogflowConnection().then(status => {
    socket.emit('connection-status', status);
  });

  socket.on('send-message', async (message) => {
    const response = await detectIntent(sessionId, message);
    socket.emit('receive-message', {
      text: response.text,
      sender: 'bot',
      timestamp: new Date().toISOString()
    });
  });

  socket.on('disconnect', () => {
    console.log('Client disconnected');
    sessions.delete(sessionId);
  });
});

const PORT = process.env.PORT || 3000;
const serverInstance = server.listen(PORT, '0.0.0.0', () => {
  const port = serverInstance.address().port;
  console.log(`Server running on port ${port}`);
  console.log(`Access the chatbot at: http://localhost:${port}`);
  
  checkDialogflowConnection().then(status => {
    console.log(`\nDialogflow Status: ${status.status.toUpperCase()}`);
    console.log(`Message: ${status.message}`);
    if (status.error) {
      console.error(`Error: ${status.error}`);
    }
  });
});

serverInstance.on('error', (error) => {
  console.error('Server error:', error);
  process.exit(1);
});

module.exports = { server };