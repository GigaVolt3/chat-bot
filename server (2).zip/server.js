require('dotenv').config();
const express = require('express');
const { SessionsClient, IntentsClient } = require('@google-cloud/dialogflow');
const cors = require('cors');
const http = require('http');
const socketIo = require('socket.io');
const fetch = require('node-fetch');
const { google } = require('googleapis');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

app.use(cors());
app.use(express.static('public'));
app.use(express.json());

// Dialogflow client configuration
const dialogflowConfig = {
  projectId: process.env.DIALOGFLOW_PROJECT_ID,
  credentials: {
    client_email: process.env.DIALOGFLOW_CLIENT_EMAIL,
    private_key: process.env.DIALOGFLOW_PRIVATE_KEY.replace(/\\n/g, '\n')
  }
};

const sessionClient = new SessionsClient(dialogflowConfig);
const intentsClient = new IntentsClient(dialogflowConfig);
const projectId = process.env.DIALOGFLOW_PROJECT_ID;

// Store active sessions, created intents, and decision logs
const sessions = new Map();
const createdIntents = new Set();
const decisionLogs = [];
const intentCreationRateLimit = new Map(); // Track intent creation rate per hour

// Protected/system intents that should not be modified
const PROTECTED_INTENTS = [
  'Default Welcome Intent',
  'Default Fallback Intent'
];

// Get Google OAuth2 access token
async function getAccessToken() {
  try {
    const auth = new google.auth.GoogleAuth({
      credentials: dialogflowConfig.credentials,
      scopes: ['https://www.googleapis.com/auth/cloud-platform']
    });
    
    const client = await auth.getClient();
    const tokenResponse = await client.getAccessToken();
    return tokenResponse.token;
  } catch (error) {
    console.error('Error getting access token:', error);
    throw error;
  }
}

// Get list of similar intents for context
async function getSimilarIntentsContext(userMessage, limit = 3) {
  try {
    const projectAgentPath = intentsClient.projectAgentPath(projectId);
    const [intents] = await intentsClient.listIntents({ 
      parent: projectAgentPath,
      intentView: 'INTENT_VIEW_FULL'
    });
    
    // Filter out protected intents and get basic info
    const intentsSummary = intents
      .filter(intent => !PROTECTED_INTENTS.includes(intent.displayName))
      .slice(0, limit)
      .map(intent => ({
        name: intent.displayName,
        example_phrases: intent.trainingPhrases?.slice(0, 3).map(tp => 
          tp.parts.map(p => p.text).join('')
        ) || [],
        response_examples: intent.messages?.[0]?.text?.text || []
      }));
    
    return intentsSummary;
  } catch (error) {
    console.error('Error getting similar intents context:', error);
    return [];
  }
}

// NEW: Groq Judge - evaluates Dialogflow response and decides action
async function callGroqJudge(userMessage, dfResultSummary) {
  console.log('🔍 Calling Groq Judge for evaluation...');
  console.log(`User: "${userMessage}"`);
  console.log(`DF Intent: ${dfResultSummary.intentName} (${dfResultSummary.confidence})`);
  console.log(`DF Reply: "${dfResultSummary.replyText}"`);
  
  try {
    const apiKey = process.env.GROQ_API_KEY;
    
    // Get similar intents for context
    const similarIntents = await getSimilarIntentsContext(userMessage);
    
    const systemPrompt = `You are an intelligent judge evaluating Dialogflow chatbot responses and managing intents.

INPUT:
- user_message: The user's query
- df_intent_name: The intent Dialogflow detected
- df_intent_confidence: Confidence score (0-1)
- df_reply_text: Dialogflow's proposed response
- similar_intents: Existing intents in the system

YOUR TASK:
1) Evaluate if Dialogflow's reply is appropriate and helpful
2) Decide whether to use it or generate a better response
3) Decide if we should create/update an intent for future use

DECISION RULES:
- If df_intent_confidence > 0.85 AND reply is good → use_dialogflow_reply: true
- If reply is generic, wrong, or confidence < 0.5 → use_dialogflow_reply: false, generate better answer
- NEVER create intents for: personal info (phone, email, names), one-time queries, very specific questions
- DO create intents for: common questions, reusable patterns, general queries
- If similar intent exists, prefer UPDATE over CREATE
- Protected intents (cannot modify): ${PROTECTED_INTENTS.join(', ')}
- Max 3 new intents per hour - be selective!

RESPOND WITH VALID JSON ONLY:
{
  "use_dialogflow_reply": boolean,
  "final_answer_text": "string - what user sees",
  "should_create_intent": boolean,
  "intent_action": "none" | "create" | "update",
  "intent_name": "string or null - use underscores, descriptive",
  "training_phrases": ["array of 3-5 variations or empty"],
  "response_template": "string or null - REQUIRED if should_create_intent=true, can be same as final_answer_text",
  "similar_intent_reference": "string or null - name of similar intent to update",
  "similarity_action": "none" | "prefer_existing" | "mark_duplicate",
  "notes": "brief reasoning for logging"
}

IMPORTANT: If should_create_intent is true, response_template MUST be provided (can use final_answer_text if appropriate).`;

    const userPrompt = `Evaluate this conversation:

USER MESSAGE: "${userMessage}"

DIALOGFLOW RESULT:
- Intent: ${dfResultSummary.intentName}
- Confidence: ${dfResultSummary.confidence}
- Reply: "${dfResultSummary.replyText}"

SIMILAR EXISTING INTENTS:
${JSON.stringify(similarIntents, null, 2)}

Provide your evaluation as JSON.`;

    const requestBody = {
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt }
      ],
      model: 'llama-3.1-8b-instant',
      temperature: 0.4,
      max_tokens: 600,
      response_format: { type: "json_object" }
    };

    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify(requestBody)
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Groq API error (${response.status}): ${errorText}`);
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;
    
    // Parse the JSON response
    const parsed = JSON.parse(content);
    console.log('✅ Groq Judge Decision:', JSON.stringify(parsed, null, 2));
    
    // Validate and normalize the response
    return {
      use_dialogflow_reply: parsed.use_dialogflow_reply ?? true,
      final_answer_text: parsed.final_answer_text || dfResultSummary.replyText,
      should_create_intent: parsed.should_create_intent ?? false,
      intent_action: parsed.intent_action || 'none',
      intent_name: parsed.intent_name || null,
      training_phrases: parsed.training_phrases || [],
      response_template: parsed.response_template || null,
      similar_intent_reference: parsed.similar_intent_reference || null,
      similarity_action: parsed.similarity_action || 'none',
      notes: parsed.notes || ''
    };
  } catch (error) {
    console.error('❌ Error calling Groq Judge:', error);
    // Fallback: use Dialogflow's response
    return {
      use_dialogflow_reply: true,
      final_answer_text: dfResultSummary.replyText,
      should_create_intent: false,
      intent_action: 'none',
      intent_name: null,
      training_phrases: [],
      response_template: null,
      similar_intent_reference: null,
      similarity_action: 'none',
      notes: 'Groq error - fallback to Dialogflow'
    };
  }
}

// Check rate limit for intent creation
function checkIntentCreationRateLimit(sessionId) {
  const now = Date.now();
  const hourAgo = now - (60 * 60 * 1000);
  
  if (!intentCreationRateLimit.has(sessionId)) {
    intentCreationRateLimit.set(sessionId, []);
  }
  
  const timestamps = intentCreationRateLimit.get(sessionId);
  const recentCreations = timestamps.filter(t => t > hourAgo);
  
  intentCreationRateLimit.set(sessionId, recentCreations);
  
  const MAX_INTENTS_PER_HOUR = 3;
  return recentCreations.length < MAX_INTENTS_PER_HOUR;
}

function recordIntentCreation(sessionId) {
  const timestamps = intentCreationRateLimit.get(sessionId) || [];
  timestamps.push(Date.now());
  intentCreationRateLimit.set(sessionId, timestamps);
}

// Find similar intent by name or training phrases
async function findSimilarIntent(intentName, trainingPhrases) {
  try {
    const projectAgentPath = intentsClient.projectAgentPath(projectId);
    const [intents] = await intentsClient.listIntents({ 
      parent: projectAgentPath,
      intentView: 'INTENT_VIEW_FULL'
    });
    
    // Filter out protected intents
    const searchableIntents = intents.filter(intent => 
      !PROTECTED_INTENTS.includes(intent.displayName)
    );
    
    // First, check for exact name match
    const exactMatch = searchableIntents.find(intent => 
      intent.displayName.toLowerCase() === intentName.toLowerCase()
    );
    
    if (exactMatch) {
      return exactMatch;
    }
    
    // Check for similar names (partial match)
    const similarByName = searchableIntents.find(intent => {
      const name1 = intent.displayName.toLowerCase().replace(/[_\s-]/g, '');
      const name2 = intentName.toLowerCase().replace(/[_\s-]/g, '');
      return name1.includes(name2) || name2.includes(name1);
    });
    
    if (similarByName) {
      return similarByName;
    }
    
    // Check for similar training phrases
    if (trainingPhrases && trainingPhrases.length > 0) {
      for (const intent of searchableIntents) {
        if (intent.trainingPhrases && intent.trainingPhrases.length > 0) {
          const existingPhrases = intent.trainingPhrases.map(tp => 
            tp.parts.map(p => p.text).join('').toLowerCase()
          );
          
          for (const newPhrase of trainingPhrases) {
            const newPhraseLower = newPhrase.toLowerCase();
            for (const existingPhrase of existingPhrases) {
              // Calculate similarity (simple word overlap)
              const words1 = new Set(existingPhrase.split(/\s+/));
              const words2 = new Set(newPhraseLower.split(/\s+/));
              const intersection = new Set([...words1].filter(x => words2.has(x)));
              const similarity = intersection.size / Math.min(words1.size, words2.size);
              
              if (similarity > 0.6) {
                return intent;
              }
            }
          }
        }
      }
    }
    
    return null;
  } catch (error) {
    console.error('Error finding similar intent:', error);
    return null;
  }
}

// Update existing intent with new training phrases
async function updateDialogflowIntent(existingIntent, newTrainingPhrases, newResponseText) {
  try {
    // Check if intent is protected
    if (PROTECTED_INTENTS.includes(existingIntent.displayName)) {
      console.log(`⚠️  Cannot update protected intent: ${existingIntent.displayName}`);
      return false;
    }
    
    // Get existing training phrases - KEEP ALL OF THEM
    const existingPhrases = existingIntent.trainingPhrases || [];
    const existingTexts = new Set(
      existingPhrases.map(tp => tp.parts.map(p => p.text).join('').toLowerCase())
    );
    
    // Filter out only exact duplicates (keep all unique new phrases)
    const uniqueNewPhrases = newTrainingPhrases.filter(phrase => 
      !existingTexts.has(phrase.toLowerCase())
    );
    
    if (uniqueNewPhrases.length === 0) {
      console.log(`ℹ️  No new unique phrases to add to intent: ${existingIntent.displayName}`);
      console.log(`  Existing phrases preserved: ${existingPhrases.length}`);
      return false;
    }
    
    // Format new training phrases
    const formattedNewPhrases = uniqueNewPhrases.map(phrase => ({
      type: 'EXAMPLE',
      parts: [{ text: phrase }]
    }));
    
    // Combine existing and new phrases - KEEPING ALL EXISTING ONES
    const updatedTrainingPhrases = [...existingPhrases, ...formattedNewPhrases];
    
    // Get existing responses - KEEP ALL OF THEM
    const existingMessages = existingIntent.messages || [];
    const existingResponseTexts = existingMessages
      .filter(msg => msg.text && msg.text.text)
      .flatMap(msg => msg.text.text);
    
    // Add new response ONLY if it's not already there
    let updatedMessages = [...existingMessages];
    if (newResponseText && !existingResponseTexts.includes(newResponseText)) {
      // Add as a new text response variant
      const textMessages = updatedMessages.filter(msg => msg.text);
      if (textMessages.length > 0) {
        // Add to existing text response
        if (!textMessages[0].text.text.includes(newResponseText)) {
          textMessages[0].text.text.push(newResponseText);
        }
      } else {
        // Create new text response
        updatedMessages.push({
          text: {
            text: [newResponseText]
          }
        });
      }
    }
    
    // Update the intent with ALL existing data preserved
    const updatedIntent = {
      name: existingIntent.name,
      displayName: existingIntent.displayName,
      trainingPhrases: updatedTrainingPhrases,
      messages: updatedMessages,
      priority: existingIntent.priority,
      isFallback: existingIntent.isFallback,
      webhookState: existingIntent.webhookState,
      inputContextNames: existingIntent.inputContextNames,
      outputContexts: existingIntent.outputContexts,
      parameters: existingIntent.parameters
    };
    
    console.log(`🔄 Updating intent: ${existingIntent.displayName}`);
    console.log(`  Existing training phrases: ${existingPhrases.length}`);
    console.log(`  New training phrases added: ${uniqueNewPhrases.length}`);
    console.log(`  Total training phrases: ${updatedTrainingPhrases.length}`);
    console.log(`  Total responses: ${updatedMessages.filter(m => m.text).map(m => m.text.text.length).reduce((a, b) => a + b, 0)}`);
    
    await intentsClient.updateIntent({
      intent: updatedIntent,
      languageCode: 'en'
    });
    
    console.log(`✅ Successfully updated intent: ${existingIntent.displayName}`);
    return true;
  } catch (error) {
    console.error('❌ Error updating Dialogflow intent:', error);
    return false;
  }
}

// Create new intent in Dialogflow
async function createDialogflowIntent(displayName, trainingPhrases, responseText) {
  // Safety checks
  if (!displayName || displayName.trim() === '') {
    console.log('⚠️  Intent creation skipped: empty display name');
    return false;
  }
  
  if (!trainingPhrases || trainingPhrases.length === 0) {
    console.log('⚠️  Intent creation skipped: no training phrases');
    return false;
  }
  
  if (!responseText || responseText.trim() === '') {
    console.log('⚠️  Intent creation skipped: empty response');
    return false;
  }
  
  // Check if name conflicts with protected intents
  if (PROTECTED_INTENTS.includes(displayName)) {
    console.log(`⚠️  Cannot create intent with protected name: ${displayName}`);
    return false;
  }
  
  try {
    const projectAgentPath = intentsClient.projectAgentPath(projectId);
    
    // Format training phrases for Dialogflow
    const formattedTrainingPhrases = trainingPhrases.map(phrase => ({
      type: 'EXAMPLE',
      parts: [{ text: phrase }]
    }));
    
    // Create the intent
    const intent = {
      displayName: displayName,
      trainingPhrases: formattedTrainingPhrases,
      messages: [{
        text: {
          text: [responseText]
        }
      }]
    };
    
    console.log('➕ Creating new intent:', displayName);
    const [response] = await intentsClient.createIntent({
      parent: projectAgentPath,
      intent: intent
    });
    
    console.log(`✅ Successfully created intent: ${displayName}`);
    createdIntents.add(displayName);
    return true;
  } catch (error) {
    console.error('❌ Error creating Dialogflow intent:', error);
    return false;
  }
}

// Main function to create or update intent based on Groq decision
async function processIntentAction(groqDecision, sessionId) {
  let { 
    intent_action, 
    intent_name, 
    training_phrases, 
    response_template,
    similar_intent_reference,
    similarity_action,
    final_answer_text
  } = groqDecision;
  
  // 1) Check if we should do anything
  if (intent_action === 'none' || !groqDecision.should_create_intent) {
    return { success: true, action: 'none' };
  }

  // 2) Auto-fix missing response_template using final_answer_text
  //    This solves the issue where Groq Judge returns null for response_template
  //    but still wants to create an intent
  if (!response_template || response_template.trim() === '') {
    if (final_answer_text && final_answer_text.trim() !== '') {
      response_template = final_answer_text;
      console.log('ℹ️  response_template was empty, using final_answer_text as template');
      console.log(`   Template: "${response_template.substring(0, 50)}..."`);
    }
  }
  
  // 3) Check rate limit
  if (!checkIntentCreationRateLimit(sessionId)) {
    console.log('⚠️  Rate limit reached: max 3 intents per hour');
    return { success: false, action: 'rate_limited' };
  }
  
  // 4) Final safety validation - only after trying to fix response_template
  if (!intent_name || !training_phrases || training_phrases.length === 0 || !response_template) {
    console.log('⚠️  Intent processing skipped: missing required data');
    console.log(`   intent_name: ${intent_name ? '✓' : '✗'}`);
    console.log(`   training_phrases: ${training_phrases?.length || 0} phrases`);
    console.log(`   response_template: ${response_template ? '✓' : '✗'}`);
    return { success: false, action: 'invalid_data' };
  }
  
  let success = false;
  let action = '';
  
  // Handle similarity actions
  if (similarity_action === 'prefer_existing' && similar_intent_reference) {
    console.log(`🔍 Similarity detected: updating existing intent ${similar_intent_reference}`);
    const existingIntent = await findSimilarIntent(similar_intent_reference, training_phrases);
    if (existingIntent) {
      success = await updateDialogflowIntent(existingIntent, training_phrases, response_template);
      action = 'updated_similar';
    }
  } else if (similarity_action === 'mark_duplicate' && similar_intent_reference) {
    console.log(`🏷️  Marked as duplicate of: ${similar_intent_reference}`);
    // Log for future maintenance
    decisionLogs.push({
      timestamp: new Date().toISOString(),
      action: 'mark_duplicate',
      intent1: intent_name,
      intent2: similar_intent_reference,
      training_phrases
    });
    return { success: true, action: 'marked_duplicate' };
  }
  
  // Execute create or update action
  if (!success) {
    if (intent_action === 'update') {
      const targetIntent = await findSimilarIntent(intent_name, training_phrases);
      if (targetIntent) {
        success = await updateDialogflowIntent(targetIntent, training_phrases, response_template);
        action = 'updated';
      } else {
        // Intent not found, create new one
        success = await createDialogflowIntent(intent_name, training_phrases, response_template);
        action = 'created_fallback';
      }
    } else if (intent_action === 'create') {
      // Check if similar intent exists anyway
      const similarIntent = await findSimilarIntent(intent_name, training_phrases);
      if (similarIntent) {
        console.log(`🔍 Found similar intent during creation: ${similarIntent.displayName}`);
        success = await updateDialogflowIntent(similarIntent, training_phrases, response_template);
        action = 'updated_instead';
      } else {
        success = await createDialogflowIntent(intent_name, training_phrases, response_template);
        action = 'created';
      }
    }
  }
  
  if (success) {
    recordIntentCreation(sessionId);
  }
  
  return { success, action };
}

// Check Dialogflow connection
async function checkDialogflowConnection() {
  try {
    const sessionId = 'test-session-' + Math.random().toString(36).substring(7);
    const sessionPath = sessionClient.projectAgentSessionPath(projectId, sessionId);
    
    await sessionClient.detectIntent({
      session: sessionPath,
      queryInput: {
        text: {
          text: 'test',
          languageCode: 'en-US',
        },
      },
    });
    
    return { 
      status: 'connected', 
      message: 'Successfully connected to Dialogflow.'
    };
  } catch (error) {
    console.error('Dialogflow connection error:', error);
    return { 
      status: 'error', 
      message: 'Failed to connect to Dialogflow', 
      error: error.message 
    };
  }
}

// UPDATED: Main detectIntent with Groq Judge integration
async function detectIntent(sessionId, message) {
  const sessionPath = sessionClient.projectAgentSessionPath(projectId, sessionId);
  
  const request = {
    session: sessionPath,
    queryInput: {
      text: {
        text: message,
        languageCode: 'en-US',
      },
    },
  };

  try {
    // STEP 1: Always call Dialogflow first
    console.log('\n' + '='.repeat(60));
    console.log('📨 Processing message:', message);
    console.log('='.repeat(60));
    
    const responses = await sessionClient.detectIntent(request);
    const result = responses[0].queryResult;
    
    // STEP 2: Build Dialogflow result summary
    const dfResultSummary = {
      intentName: result.intent.displayName,
      confidence: result.intentDetectionConfidence,
      replyText: result.fulfillmentText
    };
    
    console.log('🤖 Dialogflow Response:');
    console.log(`  Intent: ${dfResultSummary.intentName}`);
    console.log(`  Confidence: ${dfResultSummary.confidence.toFixed(2)}`);
    console.log(`  Reply: "${dfResultSummary.replyText}"`);
    
    // STEP 3: Call Groq Judge to evaluate
    const groqDecision = await callGroqJudge(message, dfResultSummary);
    
    // STEP 4: Determine final response text
    let finalText;
    if (groqDecision.use_dialogflow_reply) {
      finalText = groqDecision.final_answer_text || dfResultSummary.replyText;
      console.log('✅ Using Dialogflow reply (approved by Groq)');
    } else {
      finalText = groqDecision.final_answer_text;
      console.log('🔄 Using Groq-generated reply (Dialogflow rejected)');
    }
    
    // STEP 5: Process intent creation/update if needed
    if (groqDecision.should_create_intent) {
      console.log('🔧 Processing intent action...');
      console.log(`   Intent Name: ${groqDecision.intent_name}`);
      console.log(`   Action: ${groqDecision.intent_action}`);
      console.log(`   Training Phrases: ${groqDecision.training_phrases?.length || 0}`);
      console.log(`   Response Template: ${groqDecision.response_template ? '✓ provided' : '✗ missing (will use final_answer)'}`);
      
      const intentResult = await processIntentAction(groqDecision, sessionId);
      console.log(`   Result: ${intentResult.action} (success: ${intentResult.success})`);
    } else {
      console.log('ℹ️  No intent action needed (should_create_intent=false)');
    }
    
    // STEP 6: Log decision for analytics
    decisionLogs.push({
      timestamp: new Date().toISOString(),
      user_message: message,
      df_intent: dfResultSummary.intentName,
      df_confidence: dfResultSummary.confidence,
      used_df_reply: groqDecision.use_dialogflow_reply,
      final_answer: finalText,
      intent_action: groqDecision.intent_action,
      notes: groqDecision.notes
    });
    
    // Keep only last 100 logs
    if (decisionLogs.length > 100) {
      decisionLogs.shift();
    }
    
    console.log('='.repeat(60));
    console.log(`📤 Final response: "${finalText}"`);
    console.log('='.repeat(60) + '\n');
    
    return {
      text: finalText,
      intent: dfResultSummary.intentName,
      confidence: dfResultSummary.confidence,
      usedGroq: !groqDecision.use_dialogflow_reply
    };
    
  } catch (error) {
    console.error('❌ Error in detectIntent:', error);
    
    // Fallback: Generate response with Groq
    const fallbackDecision = await callGroqJudge(message, {
      intentName: 'error-fallback',
      confidence: 0,
      replyText: 'I apologize, but I encountered an error.'
    });
    
    return { 
      text: fallbackDecision.final_answer_text,
      intent: 'system-error',
      confidence: 0,
      usedGroq: true
    };
  }
}

// API endpoint to view decision logs (for debugging/analytics)
app.get('/api/logs', (req, res) => {
  res.json({
    total: decisionLogs.length,
    logs: decisionLogs.slice(-20) // Last 20 logs
  });
});

// API endpoint to view created intents
app.get('/api/intents', (req, res) => {
  res.json({
    created_intents: Array.from(createdIntents),
    protected_intents: PROTECTED_INTENTS
  });
});

// Socket.io connection
io.on('connection', (socket) => {
  console.log('🔌 New client connected:', socket.id);
  const sessionId = socket.id;
  
  sessions.set(sessionId, { id: sessionId });
  
  checkDialogflowConnection().then(status => {
    socket.emit('connection-status', status);
  });

  socket.on('send-message', async (message) => {
    const response = await detectIntent(sessionId, message);
    socket.emit('receive-message', {
      text: response.text,
      sender: 'bot',
      timestamp: new Date().toISOString(),
      metadata: {
        intent: response.intent,
        confidence: response.confidence,
        usedGroq: response.usedGroq
      }
    });
  });

  socket.on('disconnect', () => {
    console.log('🔌 Client disconnected:', socket.id);
    sessions.delete(sessionId);
  });
});

const PORT = process.env.PORT || 3000;
const serverInstance = server.listen(PORT, '0.0.0.0', () => {
  const port = serverInstance.address().port;
  console.log('\n' + '='.repeat(60));
  console.log('🚀 Server running on port', port);
  console.log(`📱 Access the chatbot at: http://localhost:${port}`);
  console.log(`📊 View logs at: http://localhost:${port}/api/logs`);
  console.log(`🎯 View intents at: http://localhost:${port}/api/intents`);
  console.log('='.repeat(60) + '\n');
  
  checkDialogflowConnection().then(status => {
    console.log(`🤖 Dialogflow Status: ${status.status.toUpperCase()}`);
    console.log(`   ${status.message}`);
    if (status.error) {
      console.error(`   Error: ${status.error}`);
    }
    console.log('');
  });
});

serverInstance.on('error', (error) => {
  console.error('❌ Server error:', error);
  process.exit(1);
});

module.exports = { server };